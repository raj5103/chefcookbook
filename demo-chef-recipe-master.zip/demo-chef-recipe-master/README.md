# demo-chef-recipe
Basic cookbook used with OpsWorks demo
